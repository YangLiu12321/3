# CSCI3170 project
Group number: 9 
XU Zhe: 1155124591 
JIANG Granxuan: 1155173294 
YANG liu: 1155141479 

compile: 
javac JavaSQL.java

run: 
java -cp .:mysql-connector-java-5.1.47.jar JavaSQL
